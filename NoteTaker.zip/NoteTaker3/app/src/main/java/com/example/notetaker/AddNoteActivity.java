package com.example.notetaker;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

import java.io.FileOutputStream;
import java.io.IOException;

public class AddNoteActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_note);

        EditText titleEditText = findViewById(R.id.titleEditText);
        EditText contentEditText = findViewById(R.id.contentEditText);
        Button saveButton = findViewById(R.id.saveButton);
        Button cancelButton = findViewById(R.id.cancelButton);

        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String noteTitle = titleEditText.getText().toString();
                String noteContent = contentEditText.getText().toString();

                saveNoteToFile(noteTitle, noteContent);

                Intent resultIntent = new Intent();
                resultIntent.putExtra("newNoteTitle", noteTitle);
                setResult(RESULT_OK, resultIntent);
                finish();
            }
        });

        cancelButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setResult(RESULT_CANCELED);
                finish();
            }
        });
    }

    private void saveNoteToFile(String title, String content) {
        try (FileOutputStream fileOutputStream = openFileOutput("notes.txt", MODE_APPEND)) {
            String note = title + ": " + content + "\n";
            fileOutputStream.write(note.getBytes());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}


