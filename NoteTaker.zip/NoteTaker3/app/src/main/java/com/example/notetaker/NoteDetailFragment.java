package com.example.notetaker;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.fragment.app.Fragment;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;

public class NoteDetailFragment extends Fragment {

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_note_detail, container, false);

        TextView titleTextView = view.findViewById(R.id.titleTextView);
        TextView contentTextView = view.findViewById(R.id.contentTextView);

        String noteTitle = getArguments().getString("noteTitle");
        titleTextView.setText(noteTitle);

        String noteContent = readNoteContentFromFile(noteTitle);
        contentTextView.setText(noteContent);

        return view;
    }

    private String readNoteContentFromFile(String noteTitle) {
        StringBuilder content = new StringBuilder();

        try (FileInputStream fileInputStream = getActivity().openFileInput("notes.txt");
             InputStreamReader inputStreamReader = new InputStreamReader(fileInputStream);
             BufferedReader reader = new BufferedReader(inputStreamReader)) {

            String line;
            while ((line = reader.readLine()) != null) {
                if (line.startsWith(noteTitle + ":")) {
                    content.append(line.substring(noteTitle.length() + 1)).append("\n");
                    break;
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return content.toString();
    }
}

