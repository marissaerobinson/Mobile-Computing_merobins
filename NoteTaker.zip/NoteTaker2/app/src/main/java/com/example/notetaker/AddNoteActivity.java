package com.example.notetaker;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

public class AddNoteActivity extends AppCompatActivity {
        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_add_note);

            final EditText noteTitleEditText = findViewById(R.id.noteTitleEditText);
            final EditText noteContentEditText = findViewById(R.id.noteContentEditText);

            // Set onClickListener for the "Save" button
            Button saveButton = findViewById(R.id.saveButton);
            saveButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    String title = noteTitleEditText.getText().toString();
                    String content = noteContentEditText.getText().toString();

                    // Save the note to a file or database
                    //...

                    // Return to MainActivity with the new note data
                    Intent resultIntent = new Intent();
                    resultIntent.putExtra("NoteTitle", title);
                    resultIntent.putExtra("NoteContent", content);
                    setResult(RESULT_OK, resultIntent);
                    finish();
                }
            });

            // Set onClickListener for the "Cancel" button
            Button cancelButton = findViewById(R.id.cancelButton);
            cancelButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    // Return to MainActivity without adding a new note
                    setResult(RESULT_CANCELED);
                    finish();
                }
            });
        }
    }
