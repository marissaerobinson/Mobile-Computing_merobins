package com.example.notetaker;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class NoteDetailActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_note_detail);

        Intent intent = getIntent();
        String title = intent.getStringExtra("NoteTitle");
        String content = intent.getStringExtra("NoteContent");

        NoteDetailFragment fragment = (NoteDetailFragment) getSupportFragmentManager().findFragmentById(R.id.noteDetailFragment);
        fragment.displayNoteDetails(title, content);
    }
}
