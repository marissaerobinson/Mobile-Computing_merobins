package com.example.listviews;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class DetailActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        String selectedFruit = getIntent().getStringExtra("fruit");
        String fruitDescription = getIntent().getStringExtra("description");

        TextView detailTextView = findViewById(R.id.detailTextView);
        detailTextView.setText("You have selected: " + selectedFruit + "\n\nDescription: " + fruitDescription);
    }
}

