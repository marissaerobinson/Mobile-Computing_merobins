package com.example.listviews;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;

import java.util.HashMap;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        String[] fruits = {"Apple", "Orange", "Banana", "Grapes", "Watermelon"};

        HashMap<String, Integer> fruitImages = new HashMap<>();
        fruitImages.put("Apple", R.drawable.apple);
        fruitImages.put("Orange", R.drawable.orange);
        fruitImages.put("Banana", R.drawable.banana);
        fruitImages.put("Watermelon", R.drawable.watermelon);
        fruitImages.put("Grapes", R.drawable.grapes);
        HashMap<String, String> fruitDescriptions = new HashMap<>();
        fruitDescriptions.put("Apple", "A sweet and crisp fruit.");
        fruitDescriptions.put("Orange", "a round citrus fruit with a yellowish to reddish orange rind.");
        fruitDescriptions.put("Banana", "a curved, yellow fruit with a thick skin and a soft sweet inside.");
        fruitDescriptions.put("Watermelon", "A large, round fruit that if often refreshing and juicy.");
        fruitDescriptions.put("Grapes", "Small, sweet, and seedless berries.");

        ArrayAdapter<String> customAdapter = new ArrayAdapter<String>(this, R.layout.custom_list_item, R.id.fruitTextView, fruits) {
            @NonNull
            @Override
            public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
                View view = super.getView(position, convertView, parent);

                ImageView imageView = view.findViewById(R.id.fruitImageView);
                String fruit = getItem(position);
                if (fruit != null && fruitImages.containsKey(fruit)) {
                    imageView.setImageResource(fruitImages.get(fruit));
                }
                return view;
            }
        };

        ListView listView = findViewById(R.id.fruitListView);
        listView.setAdapter(customAdapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Object selectedItem = parent.getItemAtPosition(position);

                if (selectedItem != null && selectedItem instanceof String) {
                    String selectedFruit = (String) selectedItem;

                    if (fruitDescriptions.containsKey(selectedFruit)) {
                        String fruitDescription = fruitDescriptions.get(selectedFruit);
                        Log.d("MainActivity", "Selected Fruit: " + selectedFruit);
                        Log.d("MainActivity", "Description: " + fruitDescription);

                        Intent intent = new Intent(MainActivity.this, DetailActivity.class);
                        intent.putExtra("fruit", selectedFruit);
                        intent.putExtra("description", fruitDescription);
                        startActivity(intent);
                    } else {
                        Log.e("MainActivity", "Description not found for: " + selectedFruit);
                    }
                } else {
                    Log.e("MainActivity", "Invalid item selected");
                }
            }
        });
    }
}
