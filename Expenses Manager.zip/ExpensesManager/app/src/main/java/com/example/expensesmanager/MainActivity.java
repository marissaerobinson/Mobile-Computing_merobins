package com.example.expensesmanager;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    private EditText descriptionEditText;
    private EditText amountEditText;
    private List<Expense> expenses;
    private ExpenseAdapter expenseAdapter;
    private ExpenseDBHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        descriptionEditText = findViewById(R.id.descriptionEditText);
        amountEditText = findViewById(R.id.amountEditText);

        expenses = new ArrayList<>();
        expenseAdapter = new ExpenseAdapter(this, expenses);

        ListView expensesListView = findViewById(R.id.expensesListView);
        expensesListView.setAdapter(expenseAdapter);

        Button submitExpenseButton = findViewById(R.id.submitExpenseButton);
        submitExpenseButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                addExpense();
            }
        });
        dbHelper = new ExpenseDBHelper(this);
        loadExpensesFromDatabase();
    }
    private void loadExpensesFromDatabase() {
        // Load expenses from the database and update the UI
        expenses.clear();
        expenses.addAll(dbHelper.getAllExpenses());
        expenseAdapter.notifyDataSetChanged();
    }
    private void addExpense() {
        String description = descriptionEditText.getText().toString().trim();
        String amountStr = amountEditText.getText().toString().trim();

        if (description.isEmpty() || amountStr.isEmpty()) {
            return;
        }

        double amount = Double.parseDouble(amountStr);

        long newExpenseId = dbHelper.insertExpense(description, amount, getCurrentDate());

        Expense expense = new Expense(newExpenseId, description, amount, getCurrentDate());

        expenses.add(expense);

        expenseAdapter.notifyDataSetChanged();

        // Clear input fields
        descriptionEditText.setText("");
        amountEditText.setText("");
    }
    private String getCurrentDate() {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
        return dateFormat.format(new Date());
    }
}

